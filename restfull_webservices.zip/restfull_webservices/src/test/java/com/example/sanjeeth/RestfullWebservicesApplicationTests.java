package com.example.sanjeeth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfullWebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
