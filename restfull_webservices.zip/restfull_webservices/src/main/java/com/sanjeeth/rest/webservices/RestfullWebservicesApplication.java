package com.sanjeeth.rest.webservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfullWebservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfullWebservicesApplication.class, args);
	}

}
